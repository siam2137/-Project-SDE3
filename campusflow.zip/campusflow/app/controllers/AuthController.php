<?php
declare(strict_types=1);

final class AuthController
{
    public static function showLogin(): void
    {
        require_guest();
        render('auth/login', ['pageTitle' => 'Log in']);
    }

    public static function showRegister(): void
    {
        require_guest();
        render('auth/register', ['pageTitle' => 'Create account']);
    }

    public static function login(): never
    {
        $email = strtolower(request_string('email', 190));
        $password = (string) ($_POST['password'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
            flash('danger', 'Enter a valid email address and password.');
            redirect('?page=login');
        }

        $stmt = db()->prepare('SELECT id, password_hash FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, $user['password_hash'])) {
            flash('danger', 'The email or password is incorrect.');
            redirect('?page=login');
        }

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $user['id'];
        unset($_SESSION['csrf_token']);
        flash('success', 'Welcome back! You are now logged in.');
        redirect('?page=dashboard');
    }

    public static function register(): never
    {
        $name = request_string('name', 120);
        $email = strtolower(request_string('email', 190));
        $department = request_string('department', 120);
        $semester = request_string('semester', 60);
        $password = (string) ($_POST['password'] ?? '');
        $confirmation = (string) ($_POST['password_confirmation'] ?? '');

        $errors = [];
        if (mb_strlen($name) < 2) $errors[] = 'Name must contain at least 2 characters.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
        if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
        if ($password !== $confirmation) $errors[] = 'Password confirmation does not match.';
        if ($department === '') $errors[] = 'Enter your department.';
        if ($semester === '') $errors[] = 'Enter your semester.';

        $check = db()->prepare('SELECT id FROM users WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) $errors[] = 'An account with this email already exists.';

        if ($errors) {
            foreach ($errors as $error) flash('danger', $error);
            redirect('?page=register');
        }

        $stmt = db()->prepare('INSERT INTO users (name, email, password_hash, department, semester, role) VALUES (?, ?, ?, ?, ?, \'student\')');
        $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $department, $semester]);
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) db()->lastInsertId();
        unset($_SESSION['csrf_token']);
        flash('success', 'Your CampusFlow account is ready. Select your courses in your profile.');
        redirect('?page=profile');
    }

    public static function logout(): never
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        redirect('?page=login');
    }
}
