<?php
declare(strict_types=1);

final class TaskController
{
    public static function index(): void
    {
        $user = require_auth();
        $courseId = filter_input(INPUT_GET, 'course_id', FILTER_VALIDATE_INT) ?: 0;
        $sql = 'SELECT t.*, c.course_code, c.course_title FROM course_tasks t INNER JOIN courses c ON c.id = t.course_id WHERE t.user_id = ?';
        $params = [(int) $user['id']];
        if ($courseId > 0) {
            $sql .= ' AND t.course_id = ?';
            $params[] = $courseId;
        }
        $sql .= ' ORDER BY t.is_done ASC, c.course_code ASC, t.created_at DESC';
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        $tasks = $stmt->fetchAll();
        $courses = all_courses();
        $openCount = count(array_filter($tasks, static fn(array $task): bool => !(bool) $task['is_done']));
        $doneCount = count($tasks) - $openCount;
        render('tasks/index', compact('user', 'tasks', 'courses', 'courseId', 'openCount', 'doneCount') + ['pageTitle' => 'Course checklist']);
    }

    public static function create(): never
    {
        $user = require_auth();
        $courseId = filter_input(INPUT_POST, 'course_id', FILTER_VALIDATE_INT) ?: 0;
        $title = request_string('title', 180);
        $check = db()->prepare('SELECT id FROM courses WHERE id = ?');
        $check->execute([$courseId]);
        if (!$check->fetch() || $title === '') {
            flash('danger', 'Choose a course and enter a task.');
            redirect('?page=tasks');
        }
        $stmt = db()->prepare('INSERT INTO course_tasks (user_id, course_id, title) VALUES (?, ?, ?)');
        $stmt->execute([$user['id'], $courseId, $title]);
        flash('success', 'Task added to your checklist.');
        redirect('?page=tasks');
    }

    public static function toggle(): never
    {
        $user = require_auth();
        $id = filter_input(INPUT_POST, 'task_id', FILTER_VALIDATE_INT) ?: 0;
        $stmt = db()->prepare('UPDATE course_tasks SET is_done = IF(is_done = 1, 0, 1) WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $user['id']]);
        flash($stmt->rowCount() ? 'success' : 'warning', $stmt->rowCount() ? 'Checklist updated.' : 'Task not found.');
        redirect('?page=tasks');
    }

    public static function delete(): never
    {
        $user = require_auth();
        $id = filter_input(INPUT_POST, 'task_id', FILTER_VALIDATE_INT) ?: 0;
        $stmt = db()->prepare('DELETE FROM course_tasks WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $user['id']]);
        flash($stmt->rowCount() ? 'success' : 'warning', $stmt->rowCount() ? 'Task deleted.' : 'Task not found.');
        redirect('?page=tasks');
    }
}
