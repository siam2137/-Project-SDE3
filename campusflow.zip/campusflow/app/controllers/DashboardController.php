<?php
declare(strict_types=1);

final class DashboardController
{
    public static function index(): void
    {
        $user = require_auth();
        $pdo = db();
        $courseStmt = $pdo->prepare('SELECT c.* FROM courses c INNER JOIN user_courses uc ON uc.course_id = c.id WHERE uc.user_id = ? ORDER BY c.course_code');
        $courseStmt->execute([$user['id']]);
        $courses = $courseStmt->fetchAll();
        $courseIds = array_map('intval', array_column($courses, 'id'));

        $reminderStmt = $pdo->prepare("SELECT d.*, c.course_code FROM deadlines d INNER JOIN courses c ON c.id = d.course_id WHERE d.user_id = ? AND d.is_completed = 0 AND d.due_datetime BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 48 HOUR) ORDER BY d.due_datetime ASC");
        $reminderStmt->execute([$user['id']]);
        $reminders = $reminderStmt->fetchAll();

        $deadlineStmt = $pdo->prepare("SELECT d.*, c.course_code FROM deadlines d INNER JOIN courses c ON c.id = d.course_id WHERE d.user_id = ? AND d.is_completed = 0 AND d.due_datetime >= NOW() ORDER BY d.due_datetime ASC LIMIT 5");
        $deadlineStmt->execute([$user['id']]);
        $upcoming = $deadlineStmt->fetchAll();

        $sessions = [];
        if ($courseIds) {
            $placeholders = implode(',', array_fill(0, count($courseIds), '?'));
            $sessionStmt = $pdo->prepare("SELECT s.*, c.course_code, u.name AS creator_name, (SELECT COUNT(*) FROM session_requests sr WHERE sr.session_id = s.id AND sr.status = 'accepted') AS accepted_count FROM study_sessions s INNER JOIN courses c ON c.id = s.course_id INNER JOIN users u ON u.id = s.creator_id WHERE s.status = 'open' AND s.session_datetime >= NOW() AND s.course_id IN ($placeholders) ORDER BY s.session_datetime ASC LIMIT 4");
            $sessionStmt->execute($courseIds);
            $sessions = $sessionStmt->fetchAll();
        }

        $taskStmt = $pdo->prepare("SELECT COUNT(*) FROM course_tasks WHERE user_id = ? AND is_done = 0");
        $taskStmt->execute([$user['id']]);
        $openTasks = (int) $taskStmt->fetchColumn();
        $postStmt = $pdo->prepare('SELECT COUNT(*) FROM course_posts WHERE user_id = ?');
        $postStmt->execute([$user['id']]);
        $myPosts = (int) $postStmt->fetchColumn();

        render('dashboard', compact('user', 'courses', 'reminders', 'upcoming', 'sessions', 'openTasks', 'myPosts') + ['pageTitle' => 'Dashboard']);
    }
}
