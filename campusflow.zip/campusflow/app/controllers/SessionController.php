<?php
declare(strict_types=1);

final class SessionController
{
    public static function index(): void
    {
        $user = require_auth();
        $q = trim((string) ($_GET['q'] ?? ''));
        $courseCode = trim((string) ($_GET['course'] ?? ''));
        $sql = "SELECT s.*, c.course_code, c.course_title, u.name AS creator_name,
                    (SELECT COUNT(*) FROM session_requests sr WHERE sr.session_id = s.id AND sr.status = 'accepted') AS accepted_count,
                    (SELECT sr2.status FROM session_requests sr2 WHERE sr2.session_id = s.id AND sr2.requester_id = ?) AS my_request
                FROM study_sessions s
                INNER JOIN courses c ON c.id = s.course_id
                INNER JOIN users u ON u.id = s.creator_id
                WHERE s.status = 'open' AND s.session_datetime >= NOW()";
        $params = [(int) $user['id']];
        if ($courseCode !== '') {
            $sql .= ' AND c.course_code = ?';
            $params[] = $courseCode;
        }
        if ($q !== '') {
            $sql .= ' AND (s.title LIKE ? OR s.topic LIKE ? OR s.location LIKE ? OR c.course_code LIKE ?)';
            $like = '%' . $q . '%';
            array_push($params, $like, $like, $like, $like);
        }
        $sql .= ' ORDER BY s.session_datetime ASC';
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        $sessions = $stmt->fetchAll();
        $courses = all_courses();

        $mineStmt = db()->prepare("SELECT s.id, s.title, s.session_datetime, c.course_code, (SELECT COUNT(*) FROM session_requests r WHERE r.session_id = s.id AND r.status = 'pending') AS pending_count FROM study_sessions s INNER JOIN courses c ON c.id = s.course_id WHERE s.creator_id = ? AND s.status = 'open' ORDER BY s.session_datetime ASC");
        $mineStmt->execute([$user['id']]);
        $mySessions = $mineStmt->fetchAll();
        render('sessions/index', compact('user', 'sessions', 'courses', 'q', 'courseCode', 'mySessions') + ['pageTitle' => 'Study groups']);
    }

    public static function create(): never
    {
        $user = require_auth();
        $courseId = filter_input(INPUT_POST, 'course_id', FILTER_VALIDATE_INT) ?: 0;
        $title = request_string('title', 180);
        $topic = request_string('topic', 255);
        $location = request_string('location', 180);
        $whenRaw = request_string('session_datetime', 30);
        $when = valid_datetime($whenRaw);
        $max = filter_input(INPUT_POST, 'max_members', FILTER_VALIDATE_INT) ?: 0;
        $courseCheck = db()->prepare('SELECT id FROM courses WHERE id = ?');
        $courseCheck->execute([$courseId]);

        if (!$courseCheck->fetch() || mb_strlen($title) < 4 || $topic === '' || $location === '' || !$when || strtotime($when) <= time() || $max < 2 || $max > 30) {
            flash('danger', 'Please complete all session fields correctly. Choose a future date and a member limit between 2 and 30.');
            redirect('?page=sessions');
        }
        $stmt = db()->prepare("INSERT INTO study_sessions (creator_id, course_id, title, topic, location, session_datetime, max_members, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'open')");
        $stmt->execute([$user['id'], $courseId, $title, $topic, $location, $when, $max]);
        flash('success', 'Your study session is now open for requests.');
        redirect('?page=sessions');
    }

    public static function requestJoin(): never
    {
        $user = require_auth();
        $sessionId = filter_input(INPUT_POST, 'session_id', FILTER_VALIDATE_INT) ?: 0;
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT id, creator_id, max_members, status, session_datetime FROM study_sessions WHERE id = ? FOR UPDATE');
            $stmt->execute([$sessionId]);
            $session = $stmt->fetch();
            if (!$session || $session['status'] !== 'open' || strtotime($session['session_datetime']) <= time() || (int) $session['creator_id'] === (int) $user['id']) {
                throw new DomainException('This session is no longer available for requests.');
            }
            $countStmt = $pdo->prepare("SELECT COUNT(*) FROM session_requests WHERE session_id = ? AND status = 'accepted'");
            $countStmt->execute([$sessionId]);
            $accepted = (int) $countStmt->fetchColumn();
            if ($accepted + 1 >= (int) $session['max_members']) {
                throw new DomainException('This session is currently full.');
            }
            $existingStmt = $pdo->prepare('SELECT id, status FROM session_requests WHERE session_id = ? AND requester_id = ?');
            $existingStmt->execute([$sessionId, $user['id']]);
            $existing = $existingStmt->fetch();
            if ($existing && $existing['status'] !== 'declined') {
                throw new DomainException('You have already submitted a request for this session.');
            }
            if ($existing) {
                $update = $pdo->prepare("UPDATE session_requests SET status = 'pending', created_at = CURRENT_TIMESTAMP WHERE id = ?");
                $update->execute([$existing['id']]);
            } else {
                $insert = $pdo->prepare("INSERT INTO session_requests (session_id, requester_id, status) VALUES (?, ?, 'pending')");
                $insert->execute([$sessionId, $user['id']]);
            }
            $pdo->commit();
            flash('success', 'Your request has been sent to the session creator.');
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('warning', $error instanceof DomainException ? $error->getMessage() : 'Could not submit your request. Please try again.');
        }
        redirect('?page=sessions');
    }

    public static function manageRequest(): never
    {
        $user = require_auth();
        $requestId = filter_input(INPUT_POST, 'request_id', FILTER_VALIDATE_INT) ?: 0;
        $decision = request_string('decision', 20);
        if (!in_array($decision, ['accepted', 'declined'], true)) {
            flash('danger', 'Invalid request action.');
            redirect('?page=sessions');
        }

        $pdo = db();
        $pdo->beginTransaction();
        try {
            $requestLookup = $pdo->prepare('SELECT session_id FROM session_requests WHERE id = ?');
            $requestLookup->execute([$requestId]);
            $sessionId = (int) $requestLookup->fetchColumn();
            if (!$sessionId) throw new DomainException('Request not found.');
            $sessionStmt = $pdo->prepare('SELECT id, creator_id, max_members, status FROM study_sessions WHERE id = ? FOR UPDATE');
            $sessionStmt->execute([$sessionId]);
            $session = $sessionStmt->fetch();
            if (!$session || (int) $session['creator_id'] !== (int) $user['id']) throw new DomainException('Only the session creator can manage requests.');
            if ($session['status'] !== 'open') throw new DomainException('This session is not open anymore.');
            $requestStmt = $pdo->prepare("SELECT id FROM session_requests WHERE id = ? AND session_id = ? AND status = 'pending' FOR UPDATE");
            $requestStmt->execute([$requestId, $sessionId]);
            if (!$requestStmt->fetch()) throw new DomainException('This request has already been handled.');

            if ($decision === 'accepted') {
                $countStmt = $pdo->prepare("SELECT COUNT(*) FROM session_requests WHERE session_id = ? AND status = 'accepted'");
                $countStmt->execute([$sessionId]);
                $accepted = (int) $countStmt->fetchColumn();
                if ($accepted + 2 > (int) $session['max_members']) {
                    throw new DomainException('There are no available places left in this session.');
                }
            }
            $update = $pdo->prepare('UPDATE session_requests SET status = ? WHERE id = ?');
            $update->execute([$decision, $requestId]);
            $pdo->commit();
            flash('success', $decision === 'accepted' ? 'Student accepted. The available places have been updated.' : 'Request declined.');
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('warning', $error instanceof DomainException ? $error->getMessage() : 'Unable to update this request.');
        }
        redirect('?page=session-requests&id=' . $sessionId);
    }

    public static function cancel(): never
    {
        $user = require_auth();
        $sessionId = filter_input(INPUT_POST, 'session_id', FILTER_VALIDATE_INT) ?: 0;
        $stmt = db()->prepare("UPDATE study_sessions SET status = 'cancelled' WHERE id = ? AND creator_id = ? AND status = 'open'");
        $stmt->execute([$sessionId, $user['id']]);
        flash($stmt->rowCount() ? 'success' : 'warning', $stmt->rowCount() ? 'Session cancelled.' : 'Session could not be cancelled.');
        redirect('?page=sessions');
    }

    public static function requestsPage(): void
    {
        $user = require_auth();
        $sessionId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
        $sessionStmt = db()->prepare('SELECT s.*, c.course_code FROM study_sessions s INNER JOIN courses c ON c.id = s.course_id WHERE s.id = ? AND s.creator_id = ?');
        $sessionStmt->execute([$sessionId, $user['id']]);
        $session = $sessionStmt->fetch();
        if (!$session) {
            flash('danger', 'You do not have permission to view those requests.');
            redirect('?page=sessions');
        }
        $requestStmt = db()->prepare('SELECT r.*, u.name, u.email FROM session_requests r INNER JOIN users u ON u.id = r.requester_id WHERE r.session_id = ? ORDER BY FIELD(r.status, \'pending\', \'accepted\', \'declined\'), r.created_at DESC');
        $requestStmt->execute([$sessionId]);
        $requests = $requestStmt->fetchAll();
        $countStmt = db()->prepare("SELECT COUNT(*) FROM session_requests WHERE session_id = ? AND status = 'accepted'");
        $countStmt->execute([$sessionId]);
        $acceptedCount = (int) $countStmt->fetchColumn();
        render('sessions/requests', compact('user', 'session', 'requests', 'acceptedCount') + ['pageTitle' => 'Join requests']);
    }
}
