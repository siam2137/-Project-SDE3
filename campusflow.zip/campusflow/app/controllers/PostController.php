<?php
declare(strict_types=1);

final class PostController
{
    public static function index(): void
    {
        $user = require_auth();
        $courseId = filter_input(INPUT_GET, 'course_id', FILTER_VALIDATE_INT) ?: 0;
        $sql = "SELECT p.*, c.course_code, u.name AS author_name,
                    (SELECT COUNT(*) FROM course_replies r WHERE r.post_id = p.id) AS reply_count
                FROM course_posts p
                INNER JOIN courses c ON c.id = p.course_id
                INNER JOIN users u ON u.id = p.user_id";
        $params = [];
        if ($courseId > 0) {
            $sql .= ' WHERE p.course_id = ?';
            $params[] = $courseId;
        }
        $sql .= ' ORDER BY p.created_at DESC LIMIT 80';
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        $posts = $stmt->fetchAll();
        $repliesByPost = [];
        if ($posts) {
            $ids = array_map('intval', array_column($posts, 'id'));
            $marks = implode(',', array_fill(0, count($ids), '?'));
            $replyStmt = db()->prepare("SELECT r.*, u.name AS author_name FROM course_replies r INNER JOIN users u ON u.id = r.user_id WHERE r.post_id IN ($marks) ORDER BY r.created_at ASC");
            $replyStmt->execute($ids);
            foreach ($replyStmt->fetchAll() as $reply) {
                $repliesByPost[$reply['post_id']][] = $reply;
            }
        }
        $courses = all_courses();
        render('posts/index', compact('user', 'posts', 'repliesByPost', 'courses', 'courseId') + ['pageTitle' => 'Course board']);
    }

    public static function create(): never
    {
        $user = require_auth();
        $courseId = filter_input(INPUT_POST, 'course_id', FILTER_VALIDATE_INT) ?: 0;
        $type = request_string('post_type', 20);
        $title = request_string('title', 180);
        $body = request_string('body', 5000);
        $rawUrl = request_string('resource_url', 2048);
        $url = null;
        $courseCheck = db()->prepare('SELECT id FROM courses WHERE id = ?');
        $courseCheck->execute([$courseId]);
        if (!$courseCheck->fetch() || !in_array($type, ['question', 'note_link'], true) || $title === '' || $body === '') {
            flash('danger', 'Choose a course and provide a title and description.');
            redirect('?page=board');
        }
        if ($type === 'note_link') {
            $url = safe_resource_url($rawUrl);
            if (!$url) {
                flash('danger', 'Enter a valid resource URL beginning with http:// or https://.');
                redirect('?page=board');
            }
        }
        $stmt = db()->prepare('INSERT INTO course_posts (user_id, course_id, post_type, title, body, resource_url) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([$user['id'], $courseId, $type, $title, $body, $url]);
        flash('success', 'Your post has been published.');
        redirect('?page=board');
    }

    public static function reply(): never
    {
        $user = require_auth();
        $postId = filter_input(INPUT_POST, 'post_id', FILTER_VALIDATE_INT) ?: 0;
        $body = request_string('body', 3000);
        $check = db()->prepare('SELECT id FROM course_posts WHERE id = ?');
        $check->execute([$postId]);
        if (!$check->fetch() || $body === '') {
            flash('danger', 'Write a reply before submitting.');
            redirect('?page=board');
        }
        $stmt = db()->prepare('INSERT INTO course_replies (post_id, user_id, body) VALUES (?, ?, ?)');
        $stmt->execute([$postId, $user['id'], $body]);
        flash('success', 'Your reply has been added.');
        redirect('?page=board#post-' . $postId);
    }
}
