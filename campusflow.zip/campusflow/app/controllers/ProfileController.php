<?php
declare(strict_types=1);

final class ProfileController
{
    public static function index(): void
    {
        $user = require_auth();
        $courses = all_courses();
        $selectedCourses = selected_course_ids((int) $user['id']);
        render('profile/index', compact('user', 'courses', 'selectedCourses') + ['pageTitle' => 'My profile']);
    }

    public static function update(): never
    {
        $user = require_auth();
        $name = request_string('name', 120);
        $department = request_string('department', 120);
        $semester = request_string('semester', 60);
        $email = strtolower(request_string('email', 190));
        if (mb_strlen($name) < 2 || $department === '' || $semester === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('danger', 'Please enter a valid name, email, department, and semester.');
            redirect('?page=profile');
        }
        $emailCheck = db()->prepare('SELECT id FROM users WHERE email = ? AND id <> ?');
        $emailCheck->execute([$email, $user['id']]);
        if ($emailCheck->fetch()) {
            flash('danger', 'That email address is already in use.');
            redirect('?page=profile');
        }

        $rawIds = $_POST['course_ids'] ?? [];
        if (!is_array($rawIds)) $rawIds = [];
        $courseIds = array_values(array_unique(array_filter(array_map('intval', $rawIds), static fn(int $id): bool => $id > 0)));
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $update = $pdo->prepare('UPDATE users SET name = ?, email = ?, department = ?, semester = ? WHERE id = ?');
            $update->execute([$name, $email, $department, $semester, $user['id']]);
            $pdo->prepare('DELETE FROM user_courses WHERE user_id = ?')->execute([$user['id']]);
            if ($courseIds) {
                $marks = implode(',', array_fill(0, count($courseIds), '?'));
                $validStmt = $pdo->prepare("SELECT id FROM courses WHERE id IN ($marks)");
                $validStmt->execute($courseIds);
                $validIds = array_map('intval', array_column($validStmt->fetchAll(), 'id'));
                $insert = $pdo->prepare('INSERT INTO user_courses (user_id, course_id) VALUES (?, ?)');
                foreach ($validIds as $courseId) $insert->execute([$user['id'], $courseId]);
            }
            $pdo->commit();
            flash('success', 'Your profile and course selections have been updated.');
        } catch (Throwable) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', 'Could not save your profile. Please try again.');
        }
        redirect('?page=profile');
    }
}
