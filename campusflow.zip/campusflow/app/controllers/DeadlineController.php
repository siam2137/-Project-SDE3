<?php
declare(strict_types=1);

final class DeadlineController
{
    public static function index(): void
    {
        $user = require_auth();
        $month = (string) ($_GET['month'] ?? date('Y-m'));
        if (!preg_match('/^\d{4}-\d{2}$/', $month) || !checkdate((int) substr($month, 5, 2), 1, (int) substr($month, 0, 4))) {
            $month = date('Y-m');
        }
        $first = new DateTimeImmutable($month . '-01');
        $start = $first->format('Y-m-d 00:00:00');
        $end = $first->modify('first day of next month')->format('Y-m-d 00:00:00');
        $stmt = db()->prepare('SELECT d.*, c.course_code FROM deadlines d INNER JOIN courses c ON c.id = d.course_id WHERE d.user_id = ? AND d.due_datetime >= ? AND d.due_datetime < ? ORDER BY d.due_datetime ASC');
        $stmt->execute([$user['id'], $start, $end]);
        $deadlines = $stmt->fetchAll();
        $byDay = [];
        foreach ($deadlines as $deadline) {
            $day = (int) (new DateTime($deadline['due_datetime']))->format('j');
            $byDay[$day][] = $deadline;
        }
        $daysInMonth = (int) $first->format('t');
        $startOffset = (int) $first->format('N') - 1;
        $previousMonth = $first->modify('-1 month')->format('Y-m');
        $nextMonth = $first->modify('+1 month')->format('Y-m');
        $upcomingStmt = db()->prepare("SELECT d.*, c.course_code FROM deadlines d INNER JOIN courses c ON c.id = d.course_id WHERE d.user_id = ? AND d.is_completed = 0 AND d.due_datetime >= NOW() ORDER BY d.due_datetime ASC LIMIT 12");
        $upcomingStmt->execute([$user['id']]);
        $upcoming = $upcomingStmt->fetchAll();
        $courses = all_courses();
        render('deadlines/index', compact('user', 'month', 'first', 'deadlines', 'byDay', 'daysInMonth', 'startOffset', 'previousMonth', 'nextMonth', 'upcoming', 'courses') + ['pageTitle' => 'Deadline calendar']);
    }

    public static function create(): never
    {
        $user = require_auth();
        $courseId = filter_input(INPUT_POST, 'course_id', FILTER_VALIDATE_INT) ?: 0;
        $title = request_string('title', 180);
        $type = request_string('type', 20);
        $due = valid_datetime(request_string('due_datetime', 30));
        $validTypes = ['exam', 'assignment', 'quiz', 'project'];
        $courseCheck = db()->prepare('SELECT id FROM courses WHERE id = ?');
        $courseCheck->execute([$courseId]);
        if (!$courseCheck->fetch() || $title === '' || !$due || !in_array($type, $validTypes, true)) {
            flash('danger', 'Enter a title, valid course, event type, and due date.');
            redirect('?page=calendar');
        }
        $stmt = db()->prepare('INSERT INTO deadlines (user_id, course_id, title, type, due_datetime) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$user['id'], $courseId, $title, $type, $due]);
        flash('success', 'Deadline added to your calendar.');
        redirect('?page=calendar');
    }

    public static function toggle(): never
    {
        $user = require_auth();
        $id = filter_input(INPUT_POST, 'deadline_id', FILTER_VALIDATE_INT) ?: 0;
        $stmt = db()->prepare('UPDATE deadlines SET is_completed = IF(is_completed = 1, 0, 1) WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $user['id']]);
        flash($stmt->rowCount() ? 'success' : 'warning', $stmt->rowCount() ? 'Deadline status updated.' : 'Deadline not found.');
        redirect('?page=calendar');
    }

    public static function delete(): never
    {
        $user = require_auth();
        $id = filter_input(INPUT_POST, 'deadline_id', FILTER_VALIDATE_INT) ?: 0;
        $stmt = db()->prepare('DELETE FROM deadlines WHERE id = ? AND user_id = ?');
        $stmt->execute([$id, $user['id']]);
        flash($stmt->rowCount() ? 'success' : 'warning', $stmt->rowCount() ? 'Deadline deleted.' : 'Deadline not found.');
        redirect('?page=calendar');
    }
}
