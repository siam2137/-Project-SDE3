<?php
declare(strict_types=1);

function e(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $destination): never
{
    header('Location: ' . $destination);
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flashes'][] = ['type' => $type, 'message' => $message];
}

function pull_flashes(): array
{
    $messages = $_SESSION['flashes'] ?? [];
    unset($_SESSION['flashes']);
    return $messages;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        http_response_code(419);
        exit('Your form session expired. Please go back, refresh the page, and try again.');
    }
}

function current_user(): ?array
{
    static $loaded = false;
    static $user = null;
    if ($loaded) {
        return $user;
    }
    $loaded = true;
    $id = $_SESSION['user_id'] ?? null;
    if (!$id) {
        return null;
    }
    $stmt = db()->prepare('SELECT id, name, email, department, semester, role, created_at FROM users WHERE id = ?');
    $stmt->execute([(int) $id]);
    $user = $stmt->fetch() ?: null;
    if (!$user) {
        unset($_SESSION['user_id']);
    }
    return $user;
}

function require_auth(): array
{
    $user = current_user();
    if (!$user) {
        flash('warning', 'Please log in to continue.');
        redirect('?page=login');
    }
    return $user;
}

function require_guest(): void
{
    if (current_user()) {
        redirect('?page=dashboard');
    }
}

function render(string $view, array $data = []): void
{
    $viewPath = APP_ROOT . '/app/views/' . $view . '.php';
    if (!is_file($viewPath)) {
        http_response_code(500);
        exit('Page template not found.');
    }
    extract($data, EXTR_SKIP);
    $pageTitle = $data['pageTitle'] ?? 'CampusFlow';
    require APP_ROOT . '/app/views/layouts/header.php';
    require $viewPath;
    require APP_ROOT . '/app/views/layouts/footer.php';
}

function request_string(string $key, int $maxLength = 255): string
{
    $value = $_POST[$key] ?? '';
    if (!is_string($value)) {
        return '';
    }
    return trim(mb_substr($value, 0, $maxLength));
}

function valid_datetime(string $value): ?string
{
    if ($value === '') {
        return null;
    }
    $date = DateTime::createFromFormat('Y-m-d\\TH:i', $value);
    $errors = DateTime::getLastErrors();
    if (!$date || ($errors && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))) {
        return null;
    }
    return $date->format('Y-m-d H:i:s');
}

function safe_resource_url(string $url): ?string
{
    if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
        return null;
    }
    $parts = parse_url($url);
    if (!$parts || !isset($parts['scheme'], $parts['host'])) {
        return null;
    }
    if (!in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
        return null;
    }
    return $url;
}

function selected_course_ids(int $userId): array
{
    $stmt = db()->prepare('SELECT course_id FROM user_courses WHERE user_id = ?');
    $stmt->execute([$userId]);
    return array_map('intval', array_column($stmt->fetchAll(), 'course_id'));
}

function all_courses(): array
{
    return db()->query('SELECT id, course_code, course_title, semester_label FROM courses ORDER BY course_code')->fetchAll();
}

function course_name(int $courseId): string
{
    $stmt = db()->prepare('SELECT course_code, course_title FROM courses WHERE id = ?');
    $stmt->execute([$courseId]);
    $course = $stmt->fetch();
    return $course ? $course['course_code'] . ' · ' . $course['course_title'] : 'Unknown course';
}

function format_datetime(?string $value, string $format = 'M j, Y · g:i A'): string
{
    if (!$value) {
        return 'Not set';
    }
    try {
        return (new DateTime($value))->format($format);
    } catch (Throwable) {
        return (string) $value;
    }
}

function badge_class(string $type): string
{
    return match ($type) {
        'exam' => 'text-bg-danger',
        'assignment' => 'text-bg-primary',
        'quiz' => 'text-bg-warning',
        'project' => 'text-bg-success',
        'question' => 'text-bg-info',
        'note_link' => 'text-bg-secondary',
        'accepted' => 'text-bg-success',
        'pending' => 'text-bg-warning',
        'declined' => 'text-bg-danger',
        default => 'text-bg-light',
    };
}
