<div class="page-heading d-flex flex-wrap align-items-end justify-content-between gap-3">
    <div><div class="eyebrow">YOUR STUDENT HUB</div><h1>Hey, <?= e(explode(' ', trim($user['name']))[0]) ?> <span class="wave">✦</span></h1><p class="text-muted mb-0">Here’s what’s happening with your courses.</p></div>
    <a class="btn btn-primary" href="?page=sessions">Find a study group <span class="ms-1">→</span></a>
</div>

<?php if ($reminders): ?>
<section class="reminder-banner mb-4"><div class="reminder-icon">◷</div><div class="flex-grow-1"><div class="d-flex align-items-center flex-wrap gap-2"><strong>Upcoming in 48 hours</strong><span class="reminder-count"><?= count($reminders) ?> <?= count($reminders) === 1 ? 'deadline' : 'deadlines' ?></span></div><p class="mb-2 small">A little preparation now can save you a stressful night later.</p><div class="d-flex flex-wrap gap-2"><?php foreach ($reminders as $item): ?><a class="reminder-item" href="?page=calendar"><span class="fw-semibold"><?= e($item['title']) ?></span><span class="opacity-75"><?= e($item['course_code']) ?> · <?= e(format_datetime($item['due_datetime'], 'M j, g:i A')) ?></span></a><?php endforeach; ?></div></div><a href="?page=calendar" class="reminder-link">View calendar →</a></section>
<?php else: ?>
<section class="calm-banner mb-4"><span class="calm-icon">✓</span><div><strong>You’re clear for the next 48 hours.</strong><p class="mb-0 small">No upcoming deadlines in your reminder window. Keep the momentum going.</p></div><a class="ms-auto" href="?page=calendar">Open calendar →</a></section>
<?php endif; ?>

<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3"><div class="stat-card"><div class="stat-top"><span>My courses</span><span class="stat-icon tint-purple">▦</span></div><div class="stat-number"><?= count($courses) ?></div><div class="stat-foot">Active course tags</div></div></div>
    <div class="col-6 col-lg-3"><div class="stat-card"><div class="stat-top"><span>Open tasks</span><span class="stat-icon tint-blue">☷</span></div><div class="stat-number"><?= $openTasks ?></div><div class="stat-foot"><a href="?page=tasks">View checklist →</a></div></div></div>
    <div class="col-6 col-lg-3"><div class="stat-card"><div class="stat-top"><span>48-hour alerts</span><span class="stat-icon tint-orange">◷</span></div><div class="stat-number"><?= count($reminders) ?></div><div class="stat-foot">Incomplete deadlines</div></div></div>
    <div class="col-6 col-lg-3"><div class="stat-card"><div class="stat-top"><span>My posts</span><span class="stat-icon tint-green">✎</span></div><div class="stat-number"><?= $myPosts ?></div><div class="stat-foot"><a href="?page=board">Course discussions →</a></div></div></div>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <section class="content-card h-100"><div class="section-heading"><div><div class="eyebrow">LEARN TOGETHER</div><h2>Study groups for you</h2></div><a class="text-link" href="?page=sessions">Explore all <span>→</span></a></div>
            <?php if (!$courses): ?><div class="empty-state"><div class="empty-icon">▦</div><h3>Add your courses first</h3><p>Choose your current courses to see relevant sessions on your dashboard.</p><a class="btn btn-outline-primary" href="?page=profile">Select courses</a></div>
            <?php elseif (!$sessions): ?><div class="empty-state"><div class="empty-icon">☕</div><h3>No matching sessions yet</h3><p>Start a study session and invite classmates to join you.</p><a class="btn btn-outline-primary" href="?page=sessions">Create a session</a></div>
            <?php else: ?>
                <div class="session-list"> <?php foreach ($sessions as $session): ?><div class="mini-session"><div class="session-date"><strong><?= e((new DateTime($session['session_datetime']))->format('d')) ?></strong><span><?= e((new DateTime($session['session_datetime']))->format('M')) ?></span></div><div class="flex-grow-1 min-w-0"><div class="d-flex flex-wrap align-items-center gap-2"><span class="course-tag"><?= e($session['course_code']) ?></span><span class="tiny muted">by <?= e($session['creator_name']) ?></span></div><h3><?= e($session['title']) ?></h3><p><?= e($session['topic']) ?></p><div class="tiny muted">⌖ <?= e($session['location']) ?> · <?= e(format_datetime($session['session_datetime'], 'g:i A')) ?></div></div><a class="arrow-circle" href="?page=sessions" aria-label="Browse study groups">→</a></div><?php endforeach; ?></div>
            <?php endif; ?>
        </section>
    </div>
    <div class="col-lg-5">
        <section class="content-card h-100"><div class="section-heading"><div><div class="eyebrow">STAY PREPARED</div><h2>Next deadlines</h2></div><a class="text-link" href="?page=calendar">All deadlines →</a></div>
            <?php if (!$upcoming): ?><div class="empty-state compact"><div class="empty-icon">✓</div><h3>Nothing on the horizon</h3><p>Add an exam, assignment or project milestone when you have one.</p></div>
            <?php else: ?><div class="deadline-list"><?php foreach ($upcoming as $deadline): ?><div class="deadline-row"><div class="deadline-type-mark <?= 'mark-' . e($deadline['type']) ?>"></div><div class="flex-grow-1 min-w-0"><div class="d-flex align-items-center gap-2 flex-wrap"><strong><?= e($deadline['title']) ?></strong><span class="badge rounded-pill <?= badge_class($deadline['type']) ?>"><?= e(ucfirst($deadline['type'])) ?></span></div><div class="tiny muted"><?= e($deadline['course_code']) ?> · <?= e(format_datetime($deadline['due_datetime'], 'M j · g:i A')) ?></div></div></div><?php endforeach; ?></div><?php endif; ?>
        </section>
    </div>
</div>
<section class="content-card mt-4"><div class="section-heading"><div><div class="eyebrow">YOUR SEMESTER</div><h2>Active courses</h2></div><a class="text-link" href="?page=profile">Manage courses →</a></div>
    <?php if ($courses): ?><div class="course-grid"><?php foreach ($courses as $course): ?><a href="?page=board&course_id=<?= (int) $course['id'] ?>" class="course-tile"><span class="course-tile-icon">▤</span><span><strong><?= e($course['course_code']) ?></strong><small><?= e($course['course_title']) ?></small></span><span class="course-tile-arrow">↗</span></a><?php endforeach; ?></div><?php else: ?><p class="text-muted mb-0">No courses selected. <a href="?page=profile">Add courses in your profile</a>.</p><?php endif; ?>
</section>
