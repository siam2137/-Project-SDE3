<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f6f7fb">
    <title><?= e($pageTitle) ?> · <?= e($GLOBALS['config']['app_name']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<?php $layoutUser = current_user(); ?>
<?php if ($layoutUser): ?>
<nav class="navbar navbar-expand-lg navbar-campus sticky-top">
    <div class="container-xl">
        <a class="navbar-brand brand-mark" href="?page=dashboard"><span class="brand-icon">C</span> CampusFlow</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav mx-auto nav-links">
                <li class="nav-item"><a class="nav-link <?= $pageTitle === 'Dashboard' ? 'active' : '' ?>" href="?page=dashboard">Overview</a></li>
                <li class="nav-item"><a class="nav-link <?= $pageTitle === 'Study groups' || $pageTitle === 'Join requests' ? 'active' : '' ?>" href="?page=sessions">Study groups</a></li>
                <li class="nav-item"><a class="nav-link <?= $pageTitle === 'Deadline calendar' ? 'active' : '' ?>" href="?page=calendar">Deadlines</a></li>
                <li class="nav-item"><a class="nav-link <?= $pageTitle === 'Course board' ? 'active' : '' ?>" href="?page=board">Course board</a></li>
                <li class="nav-item"><a class="nav-link <?= $pageTitle === 'Course checklist' ? 'active' : '' ?>" href="?page=tasks">Checklist</a></li>
            </ul>
            <div class="d-flex align-items-center gap-2 profile-nav">
                <a class="avatar avatar-sm" href="?page=profile" title="My profile"><?= e(mb_strtoupper(mb_substr($layoutUser['name'], 0, 1))) ?></a>
                <div class="d-none d-lg-block lh-sm"><div class="small fw-bold"><?= e($layoutUser['name']) ?></div><div class="tiny muted">Student account</div></div>
                <form method="post" class="ms-lg-2">
                    <?= csrf_field() ?><input type="hidden" name="action" value="logout">
                    <button class="btn btn-sm btn-outline-secondary btn-logout" type="submit">Log out</button>
                </form>
            </div>
        </div>
    </div>
</nav>
<?php endif; ?>
<main class="<?= $layoutUser ? 'app-main' : 'auth-main' ?>">
<div class="container-xl">
    <?php foreach (pull_flashes() as $message): ?>
        <div class="alert alert-<?= e($message['type']) ?> alert-dismissible fade show flash-message" role="alert">
            <?= e($message['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endforeach; ?>
