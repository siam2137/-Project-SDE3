</div>
</main>
<footer class="footer-campus"><div class="container-xl d-flex flex-wrap justify-content-between gap-2"><span>© <?= date('Y') ?> CampusFlow</span><span>Study together. Stay on track.</span></div></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
