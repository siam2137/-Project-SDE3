<div class="auth-shell register-shell row g-0 mx-auto">
    <div class="col-lg-5 auth-panel d-none d-lg-flex"><div class="auth-panel-content"><div class="brand-mark brand-mark-light mb-5"><span class="brand-icon">C</span> CampusFlow</div><div class="register-illustration"><div class="register-circle">✦</div><div class="register-pill pill-a">Study groups</div><div class="register-pill pill-b">Your deadlines</div><div class="register-pill pill-c">Course notes</div></div><h2>Your campus life,<br>more connected.</h2><p>Build your study circle and make the most of every course.</p></div></div>
    <div class="col-lg-7 auth-form-panel"><div class="auth-form-inner register-inner"><div class="brand-mark mobile-brand mb-4"><span class="brand-icon">C</span> CampusFlow</div><div class="eyebrow">GET STARTED</div><h1 class="auth-title">Create your account</h1><p class="text-muted mb-4">A few details and you’re ready to go.</p>
        <form method="post" action="?page=register" class="row g-3">
            <?= csrf_field() ?><input type="hidden" name="action" value="register">
            <div class="col-md-6"><label class="form-label" for="name">Full name</label><input class="form-control" id="name" name="name" required maxlength="120" placeholder="Your name" autocomplete="name"></div>
            <div class="col-md-6"><label class="form-label" for="email">Email</label><input class="form-control" id="email" type="email" name="email" required maxlength="190" placeholder="you@university.edu" autocomplete="email"></div>
            <div class="col-12"><label class="form-label" for="department">Department</label><input class="form-control" id="department" name="department" required maxlength="120" placeholder="e.g. Computer Science & Engineering"></div>
            <div class="col-12"><label class="form-label" for="semester">Current year / semester</label><input class="form-control" id="semester" name="semester" required maxlength="60" placeholder="e.g. 3rd Year · 1st Semester"></div>
            <div class="col-md-6"><label class="form-label" for="password">Password</label><input class="form-control" id="password" type="password" name="password" minlength="8" required autocomplete="new-password" placeholder="At least 8 characters"></div>
            <div class="col-md-6"><label class="form-label" for="password_confirmation">Confirm password</label><input class="form-control" id="password_confirmation" type="password" name="password_confirmation" minlength="8" required autocomplete="new-password" placeholder="Enter it again"></div>
            <div class="col-12"><button class="btn btn-primary btn-lg w-100" type="submit">Create account <span class="ms-1">→</span></button></div>
        </form>
        <p class="auth-switch mt-4">Already have an account? <a href="?page=login">Log in</a></p>
    </div></div>
</div>
