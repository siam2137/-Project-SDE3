<div class="auth-shell row g-0 mx-auto">
    <div class="col-lg-6 auth-panel d-none d-lg-flex">
        <div class="auth-panel-content">
            <div class="brand-mark brand-mark-light mb-5"><span class="brand-icon">C</span> CampusFlow</div>
            <div class="auth-art"><div class="art-orbit orbit-one"></div><div class="art-orbit orbit-two"></div><div class="art-card art-card-main"><div class="art-card-dot"></div><div class="art-line w-50"></div><div class="art-line w-75"></div><div class="art-progress"><span></span></div><div class="d-flex gap-2 mt-4"><i></i><i></i><i></i></div></div><div class="art-card art-card-float"><span class="float-check">✓</span><div class="art-line w-75"></div><div class="art-line w-50"></div></div></div>
            <h2>Make your semester<br>work for you.</h2>
            <p>Find your people, share what you know, and keep every deadline in sight.</p>
            <div class="auth-perks"><span>✦ Course-based study groups</span><span>✦ One place for every deadline</span><span>✦ Helpful notes and answers</span></div>
        </div>
    </div>
    <div class="col-lg-6 auth-form-panel">
        <div class="auth-form-inner">
            <div class="brand-mark mobile-brand mb-4"><span class="brand-icon">C</span> CampusFlow</div>
            <div class="eyebrow">WELCOME BACK</div>
            <h1 class="auth-title">Log in to your space</h1>
            <p class="text-muted mb-4">Pick up where you left off.</p>
            <form method="post" action="?page=login" class="vstack gap-3">
                <?= csrf_field() ?><input type="hidden" name="action" value="login">
                <div><label class="form-label" for="email">University email</label><input class="form-control form-control-lg" id="email" type="email" name="email" placeholder="you@university.edu" required autocomplete="email"></div>
                <div><label class="form-label" for="password">Password</label><input class="form-control form-control-lg" id="password" type="password" name="password" placeholder="Enter your password" required autocomplete="current-password"></div>
                <button class="btn btn-primary btn-lg mt-2" type="submit">Log in <span class="ms-1">→</span></button>
            </form>
            <p class="auth-switch mt-4">New to CampusFlow? <a href="?page=register">Create an account</a></p>
            <div class="demo-hint"><strong>Demo account</strong><br>siam@campusflow.test · Campus123!</div>
        </div>
    </div>
</div>
