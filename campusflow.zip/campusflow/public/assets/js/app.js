(() => {
    'use strict';

    document.querySelectorAll('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            const message = form.getAttribute('data-confirm') || 'Are you sure?';
            if (!window.confirm(message)) event.preventDefault();
        });
    });

    const typeSelect = document.getElementById('post_type');
    const resourceWrap = document.getElementById('resource-url-wrap');
    const resourceInput = document.getElementById('resource_url');
    const syncResourceField = () => {
        if (!typeSelect || !resourceWrap) return;
        const show = typeSelect.value === 'note_link';
        resourceWrap.classList.toggle('d-none', !show);
        if (resourceInput) resourceInput.required = show;
    };
    if (typeSelect) {
        typeSelect.addEventListener('change', syncResourceField);
        syncResourceField();
    }

    // Dismiss transient flash messages after a short pause, while keeping the close button available.
    document.querySelectorAll('.flash-message').forEach((alert) => {
        window.setTimeout(() => {
            if (window.bootstrap) bootstrap.Alert.getOrCreateInstance(alert).close();
        }, 6500);
    });
})();
