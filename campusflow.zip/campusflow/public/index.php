<?php
declare(strict_types=1);

require dirname(__DIR__) . '/app/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = request_string('action', 60);
    $actions = [
        'login' => [AuthController::class, 'login'],
        'register' => [AuthController::class, 'register'],
        'logout' => [AuthController::class, 'logout'],
        'profile_update' => [ProfileController::class, 'update'],
        'session_create' => [SessionController::class, 'create'],
        'session_request' => [SessionController::class, 'requestJoin'],
        'session_request_manage' => [SessionController::class, 'manageRequest'],
        'session_cancel' => [SessionController::class, 'cancel'],
        'deadline_create' => [DeadlineController::class, 'create'],
        'deadline_toggle' => [DeadlineController::class, 'toggle'],
        'deadline_delete' => [DeadlineController::class, 'delete'],
        'post_create' => [PostController::class, 'create'],
        'reply_create' => [PostController::class, 'reply'],
        'task_create' => [TaskController::class, 'create'],
        'task_toggle' => [TaskController::class, 'toggle'],
        'task_delete' => [TaskController::class, 'delete'],
    ];
    if (!isset($actions[$action])) {
        http_response_code(400);
        exit('Unknown form action.');
    }
    call_user_func($actions[$action]);
    exit;
}

$page = (string) ($_GET['page'] ?? (current_user() ? 'dashboard' : 'login'));
$routes = [
    'login' => [AuthController::class, 'showLogin'],
    'register' => [AuthController::class, 'showRegister'],
    'dashboard' => [DashboardController::class, 'index'],
    'sessions' => [SessionController::class, 'index'],
    'session-requests' => [SessionController::class, 'requestsPage'],
    'calendar' => [DeadlineController::class, 'index'],
    'board' => [PostController::class, 'index'],
    'tasks' => [TaskController::class, 'index'],
    'profile' => [ProfileController::class, 'index'],
];
if (!isset($routes[$page])) {
    http_response_code(404);
    render('not-found', ['pageTitle' => 'Page not found']);
    exit;
}

try {
    call_user_func($routes[$page]);
} catch (Throwable $error) {
    http_response_code(500);
    if ($GLOBALS['config']['debug']) {
        echo '<pre>' . e($error->getMessage()) . "\n" . e($error->getTraceAsString()) . '</pre>';
    } else {
        render('error', ['pageTitle' => 'Something went wrong']);
    }
}
